'use client';

function fileIcon(name) {
  const ext = (name || '').split('.').pop().toLowerCase();
  if (['jpg','jpeg','png','gif','webp'].includes(ext)) return '🖼';
  if (ext === 'pdf') return '📄';
  return '📎';
}

export default function AttachmentTab({
  attachments, setAttachments, processOCR, ocrStatus, ocrCls, fileRef
}) {
  return (
    <div>
      {/* Drop area */}
      <div
        onClick={() => fileRef.current?.click()}
        onDragOver={e => e.preventDefault()}
        onDrop={e => { e.preventDefault(); processOCR(Array.from(e.dataTransfer.files)); }}
        style={{
          border: '1.5px dashed var(--border2)', borderRadius: 'var(--radius-lg)',
          padding: '1.25rem', marginBottom: '1.25rem', textAlign: 'center',
          cursor: 'pointer', transition: 'all 0.15s', background: 'var(--surface)',
        }}
      >
        <input ref={fileRef} type="file" accept="image/*,.pdf" multiple onChange={e => processOCR(Array.from(e.target.files))} style={{ display: 'none' }}/>
        <div style={{ fontSize: 14, color: 'var(--text2)' }}>
          <strong style={{ color: 'var(--accent-text)' }}>Clique aqui ou arraste</strong> para fazer upload ou OCR
        </div>
        <div style={{ fontSize: 12, color: 'var(--text3)', marginTop: 4 }}>PDF, imagem • Extrai dados automaticamente via Gemini</div>
      </div>

      {/* OCR status */}
      {ocrStatus && (
        <div style={{ fontSize: 13, marginBottom: '1rem', color: ocrCls === 'loading' ? 'var(--warning)' : ocrCls === 'success' ? 'var(--accent)' : 'var(--danger)' }}>
          {ocrStatus}
        </div>
      )}

      {/* Attachment list */}
      <div style={{ display: 'flex', flexWrap: 'wrap', gap: 8 }}>
        {attachments.map((a, i) => (
          <div key={i} className="attach-chip" style={{ maxWidth: 220 }}>
            <span style={{ fontSize: 14, flexShrink: 0 }}>{fileIcon(a.name)}</span>
            <span style={{ overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap', flex: 1 }} title={a.name}>{a.name}</span>
            <button
              onClick={() => setAttachments(att => att.filter((_, j) => j !== i))}
              style={{ background: 'none', border: 'none', cursor: 'pointer', color: 'var(--text3)', fontSize: 13, padding: 0, lineHeight: 1 }}
            >✕</button>
          </div>
        ))}
        {attachments.length === 0 && (
          <div style={{ fontSize: 13, color: 'var(--text3)' }}>Nenhum anexo</div>
        )}
      </div>
    </div>
  );
}
